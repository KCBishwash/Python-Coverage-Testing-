# Why it is robust

- Empty line will not break my program
- Invalid instructions will not break this system
- It also has powerful correction capability:
    - Instructions are case insensitive
    - Even you miss the space between an instruction and its operand when you input an instruction, 
    it automatically corrects it and runs smoothly. Such as w-100, p7, etc.
- It supports minus degree or distance.
- It supports long format instructions and short format instructions.
 
    